const BASE_URL = "https://tascom.up.railway.app";

export interface Reporter {
  id: number;
  name: string;
  email: string;
}

export interface Report {
  id: number;
  reportedId: number;
  createdById: number;
  reason: string;
  type: "USER" | "TASK";
  status: "PENDING" | "RESOLVED" | "REJECTED";
  createdAt: string;
  reporter: Reporter;
}


export const getReportedUsers = async (): Promise<Report[]> => {
  const token = localStorage.getItem("access-token");
  const res = await fetch(`${BASE_URL}/reports/reported-users`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error("Failed to fetch reports");
  return res.json();
};


export const reportUser = async (payload: {
  reportedId: number;
  reason: string;
}): Promise<void> => {
  const token = localStorage.getItem("access_token");
  const res = await fetch(`${BASE_URL}/reports`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(payload),
  });
  if (!res.ok) throw new Error("Failed to submit report");
};