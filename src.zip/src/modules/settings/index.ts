export { settingsRoutes } from './routes';
