export { notificationsRoutes } from './routes';
