export { topResultsRoutes } from './routes';
